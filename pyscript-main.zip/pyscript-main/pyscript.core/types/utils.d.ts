export function htmlDecode(html: any): string;
