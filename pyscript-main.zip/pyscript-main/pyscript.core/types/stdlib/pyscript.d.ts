declare namespace _default {
    let pyscript: {
        "__init__.py": string;
        "display.py": string;
        "event_handling.py": string;
        "magic_js.py": string;
        "util.py": string;
    };
    let pyweb: {
        "pydom.py": string;
    };
}
export default _default;
