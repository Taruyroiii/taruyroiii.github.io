declare const _default: Map<string, string>;
export default _default;
